tugma.onclick = () =>{  
  if(inp.value == "bmw"){  
    rasm.src = "bmw.jpg"; 
    rasm.style.display = "block";
  }  
  if(inp.value == "audi"){  
    rasm.src = "audi.jpg";
    rasm.style.display = "block";
  }  
    if(inp.value == "porsche"){  
    rasm.src = "porsche.jpg";
    rasm.style.display = "block";
  } 
  if(inp.value == "ferrari"){  
    rasm.src = "ferrari.jpg";
    rasm.style.display = "block";
  }  
  if(inp.value == "mersederc"){  
    rasm.src = "msrsederc.jpg";
    rasm.style.display = "block";
  }  
  if(inp.value == "nexia"){  
    rasm.src = "nexia.jpg";
    rasm.style.display = "block";
  }  
  if(inp.value == "gentra"){  
    rasm.src = "gentra.jpg";
    rasm.style.display = "block";
  }  
  if(inp.value == "malibu"){  
    rasm.src = "malibu.jpg";
    rasm.style.display = "block";
  }  
}  